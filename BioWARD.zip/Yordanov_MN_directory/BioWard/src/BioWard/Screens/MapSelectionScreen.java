package BioWard.Screens;

import BioWard.BioWard;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;


public class MapSelectionScreen extends Pane implements ScreenIF
{
	Canvas canvas;
	GraphicsContext graphicsContext;

	/**
	 * Create a new MapSelectionScreen
	 */
	public MapSelectionScreen()
	{
		canvas = new Canvas(BioWard.STAGE_WIDTH, BioWard.STAGE_HEIGHT);
		graphicsContext = canvas.getGraphicsContext2D();



		// Create button to return to main menu
		Button buttonReturnToMenu = new Button("Return to Menu");
		buttonReturnToMenu.setFont(new Font("Cooper Black", 16));
		buttonReturnToMenu.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event)
			{
				BioWard.updateScene(new MainMenuScreen());
			}
		});
		buttonReturnToMenu.setMinSize(160,40);
		buttonReturnToMenu.setMaxSize(160, 40);
		buttonReturnToMenu.setLayoutX(10);
		buttonReturnToMenu.setLayoutY(10);


		// Create a button to select the 2nd map
		Button buttonMiddleMap = new Button("Play");
		buttonMiddleMap.setFont(new Font("Cooper Black", 24));
		buttonMiddleMap.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event)
			{
				System.out.println("Middle Map Selected");
				BioWard.updateScene(new GameScreen(2));
			}
		});
		buttonMiddleMap.setMinSize(200, 45);
		buttonMiddleMap.setMaxSize(200, 45);
		buttonMiddleMap.setLayoutX(424);
		buttonMiddleMap.setLayoutY(420);

		
		getChildren().addAll(canvas, buttonReturnToMenu, buttonMiddleMap);
	}

	/**
	 * Set the canvas and graphicsContext to null;
	 */
	@Override
	public void killScreen()
	{
		canvas = null;
		graphicsContext = null;
	}
}
