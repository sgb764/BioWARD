package BioWard.Towers;

import BioWard.FactoryIF;


public class TowerFactory implements FactoryIF
{
    /**
     * Create a new TowerFactory object
     */
    public TowerFactory()
    {}

    /**
     * Create a tower that corresponds the the given discriminator
     * @param discriminator
     * @return the requested Tower
     */
    @Override
    public Tower createProduct(int discriminator)
    {
        Tower createdTower;

        switch(discriminator)
        {
            case 1:
                createdTower = new WhiteBloodCell();
                break;
            case 2:
                createdTower = new Antibiotics();
                break;
            case 3:
                createdTower = new Vaccine();
                break;
            default:
                createdTower = null;
                break;
        }

        return createdTower;
    }
}
