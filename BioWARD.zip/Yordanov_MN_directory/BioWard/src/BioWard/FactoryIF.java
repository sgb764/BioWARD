package BioWard;


public interface FactoryIF
{
    Object createProduct(int discriminator) throws InterruptedException;
}
