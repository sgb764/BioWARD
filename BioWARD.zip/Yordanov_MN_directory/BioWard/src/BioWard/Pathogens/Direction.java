package BioWard.Pathogens;


public enum Direction implements CommandIF
{
    UP, DOWN, LEFT, RIGHT
}
