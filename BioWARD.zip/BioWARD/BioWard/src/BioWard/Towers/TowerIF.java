package BioWard.Towers;

import java.util.ArrayList;

import BioWard.Pathogens.Pathogen;


public interface TowerIF
{
    void shootPathogen(ArrayList<Pathogen> pathogens);
    void upgradeTowerRange();
    void upgradeTowerDamage();
}
