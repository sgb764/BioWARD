package BioWard.Screens;


public interface ScreenIF
{
	// killScreen should be used to free memory used by components and stop any timers that the
	// screen utilises
	void killScreen();
}
