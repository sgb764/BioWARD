package BioWard.Screens.GameScreenUIComponents;


public interface ComponentIF
{
	void update();
	void killComponent();
}
