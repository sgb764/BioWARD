package BioWard.Pathogens;


public interface QueueIF
{
    boolean isEmpty();
    CommandIF peek();
    void addCommand(CommandIF item);
    CommandIF remove();
    int getLength();
}