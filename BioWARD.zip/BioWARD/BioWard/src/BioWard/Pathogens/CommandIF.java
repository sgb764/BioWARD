package BioWard.Pathogens;


public interface CommandIF
{
}
